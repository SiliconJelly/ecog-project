# Team task: add spectral whitening and measure whether it helps

Your AI will write the code. Your job is to follow the rules below so our results can be compared fairly with Abri's version.

**Read the cheat sheet first** (`ECoG_Project_Cheat_Sheet.pdf`, in this folder). It explains what we're testing, every term used here, how 10-fold cross-validation and whitening work, and how to read each graph.

## What's in this folder

| File | What it is | Do you change it? |
|---|---|---|
| `look.py` | Loads the data and draws a plot. Run it first to check your setup works. | No |
| `classify.py` | **The main one.** Our gesture decoder (93.3% accuracy). Whitening goes here first. | Make a whitened copy |
| `baseline_state.py` | "Does the brain remember the last trial?" | Bonus: whitened copy |
| `carryover.py` | "Is the next movement's brain response smaller after a movement?" | Bonus: whitened copy |
| `fist_vs_peace_residue.py` | "Does the leftover state tell fist from peace?" | Bonus: whitened copy |
| `Hand.pdf` | The paper we compare against (Gruenwald et al. 2019). Whitening is in Section 2.4. | No |
| `data_description.pdf` | What each data channel is. | No |

You also need **`ECoG_Handpose.mat`** (the data, 118 MB). Abri will share it through Google Drive. Put it in this same folder.

## Setup (once)

1. Install Python from python.org (tick **"Add python.exe to PATH"**), or use Spyder/Anaconda if you have it.
2. In a terminal or the Spyder console, run: `pip install numpy scipy matplotlib scikit-learn`
3. Run `look.py`. It should print `Shape: (67, 507025)` and show a plot. If it does, you're ready.

## What whitening is (one paragraph)

Brain signals are much stronger at low frequencies than high ones, so the spectrum slopes steeply downhill. The decoder uses the high frequencies (50-300 Hz), where the signal is weakest. Whitening is a filter that flattens that slope, so the high-frequency activity isn't drowned out. The paper says it improved accuracy by about 11% on average. We're already at 93%, so expect a smaller gain, or none. **A "no improvement" result is still a valid result.**

## The rules (these make our results comparable)

1. **Never edit the original files.** Save new copies with `_whitened` in the name, e.g. `classify_whitened.py`.
2. **Change only one thing: add the whitening step.** Same features, same classifier, same cross-validation, same random seeds. Nothing else.
3. **Use exactly this whitening recipe**, so any difference between our versions comes from mistakes, not choices:
   - One whitening filter **per channel** (60 channels)
   - **10th-order autoregressive (AR) model**, coefficients from the **Yule-Walker equations**
   - Fit the coefficients on the **whole continuous recording** of that channel
   - Apply it as a filter with coefficients `[1, -a1, ..., -a10]`, using **`scipy.signal.lfilter`** (one direction, not filtfilt)
   - Put it **after** the notch filters and **before** the 50-300 Hz bandpass
4. **Add an on/off switch** at the top of the file: `WHITEN = True`. One file then gives both results.
5. **The most important check:** run with `WHITEN = False` first. The numbers must match the original (see the table below). A difference of 0.1 in the last decimal is OK, since library versions can vary slightly. If they're off by more than that, something else changed by accident. Stop and fix that before going on.
6. **Copy the printed output exactly** (copy-paste the text, don't retype it). Send it to Abri with your `_whitened.py` files.

## Prompt to paste into your AI

Attach `classify.py` and `Hand.pdf`, then paste this:

> I'm working on a brain-computer interface hackathon. Attached is `classify.py`, a Python script that decodes hand gestures from ECoG brain data, and the paper `Hand.pdf` (Gruenwald et al. 2019; whitening is in Section 2.4).
>
> Please make a copy called `classify_whitened.py` that adds spectral whitening, following these exact rules:
> 1. Add a switch at the top: `WHITEN = True`. When it's False, the script must behave exactly like the original.
> 2. Whitening is per channel: fit a 10th-order AR model with the Yule-Walker equations on the whole continuous recording of that channel, then filter with `scipy.signal.lfilter([1, -a1, ..., -a10], [1], x)`.
> 3. Insert it after the notch-filter loop and before the 50-300 Hz bandpass. Change nothing else: same features, classifier, cross-validation and random seeds.
> 4. Add one extra figure: the power spectrum (Welch) of channel 26 before vs after whitening, on a log scale, so we can check the spectrum got flatter.
> 5. Explain in plain language what each line you added does.
>
> Don't change any other part of the script.

When that works, do the same for the bonus scripts (`baseline_state.py`, `carryover.py`, `fist_vs_peace_residue.py`). Use the same prompt, but swap the file name.

## Results to send back

Fill this in from your printed output:

| Script | Number | Original (must match when WHITEN = False) | WHITEN = True |
|---|---|---|---|
| classify | 3-class accuracy | 93.3% +/- 7.4% | |
| classify | Fist vs Peace only | 93.5% +/- 9.4% | |
| classify | Shuffled-label control (should stay ~33%) | 33.8% | |
| classify | Confusion matrix | 28/2/0, 2/28/0, 0/2/28 | |
| baseline_state | Motor beta after movement vs open | +1.63 dB, p=0.0018 | |
| baseline_state | Decode "previous trial was a movement" | 75% | |
| carryover | Regression, response size | -0.44 dB, p=0.004 | |
| fist_vs_peace_residue | Brain decodes last fist vs peace | 55% | |

Also send:

- the before/after spectrum plot
- anything that errored, with the full red error text

## If something goes wrong

- `FileNotFoundError ... ECoG_Handpose.mat`: the data file isn't in the same folder as the script.
- `ModuleNotFoundError`: run the `pip install` line from Setup again.
- Numbers don't match the original with `WHITEN = False`: the AI changed something besides whitening. Ask it: "Show me every line that differs from the original file, other than the whitening step."
- Accuracy drops a lot with whitening (below ~85%): note it and send it anyway. That's a result too, but double-check rule 3 first.
